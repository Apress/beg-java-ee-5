package com.apress.servlet;

import javax.servlet.http.*;
import java.io.*;
import java.util.logging.Logger;

public class Login extends HttpServlet {
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
  {
    Logger logger = Logger.getLogger("com.apress.beginjavaee");
    logger.info("Entered Login servlet doPost()");
    String username = request.getParameter("username");
    String password = request.getParameter("password");
    HttpSession session = request.getSession(true); //Will create first time
    session.setAttribute("username", username);
    session.setAttribute("password", password);
    try {
      response.setContentType("text/html");
      PrintWriter writer = response.getWriter();
      writer.println("<html><head><title>Logged On</title></head><body>");
      writer.println("Thank you, " + username +
                     ". You are now logged into the system.");
      String newURL = response.encodeURL("GetSession");
	writer.println("Click <a href=\"" + newURL + "\">here</a> for another servlet");
      writer.println("</body></html>");
      writer.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    logger.info("Login doPost() finished processing");
  }
}