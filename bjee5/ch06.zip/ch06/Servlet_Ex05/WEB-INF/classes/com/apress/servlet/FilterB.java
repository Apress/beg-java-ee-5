package com.apress.servlet;

import java.util.logging.Logger;

import javax.servlet.*;

public class FilterB implements Filter {
  private ServletContext context;
  public void init(FilterConfig filterConfig) {
    context = filterConfig.getServletContext();
  }

  public void doFilter(
    ServletRequest request,
    ServletResponse response,
    FilterChain chain) {
      Logger logger = Logger.getLogger("com.apress.beginjavaee");
      logger.info("Entered FilterB.doFilter()");
      logger.info("protocol is " + request.getProtocol());
      logger.info("remote host is " + request.getRemoteHost());
      logger.info("content type is " + request.getContentType());
      logger.info("content length is " + request.getContentLength());
      logger.info("username is " + request.getParameter("username")); 
      logger.info("FilterB passing request to next filter");

      try {
        chain.doFilter(request, response);
      } catch (Exception e) {
        e.printStackTrace();
      }

      logger.info("Returned to FilterB.doFilter()");
      logger.info("FilterB is now processing the response");
  }

  public void destroy() {}
}