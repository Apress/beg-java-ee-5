package com.apress.servlet;

import java.util.logging.Logger;

import javax.servlet.*;

public class FilterA implements Filter {
  private ServletContext context;
  public void init(FilterConfig filterConfig) {
    context = filterConfig.getServletContext();
  }

  public void doFilter(
    ServletRequest request,
    ServletResponse response,
    FilterChain chain) {
      Logger logger = Logger.getLogger("com.apress.beginjavaee");
      logger.info("Entered FilterA.doFilter()");
      logger.info("FilterA passing request to next filter");

      try {
        chain.doFilter(request, response);
      } catch (Exception e) {
        System.out.println("Exception on doFilter" + e.getMessage());
      }

      logger.info("Returned to FilterA.doFilter()");
      logger.info("FilterA is now processing the response");
  }

  public void destroy() {}
}