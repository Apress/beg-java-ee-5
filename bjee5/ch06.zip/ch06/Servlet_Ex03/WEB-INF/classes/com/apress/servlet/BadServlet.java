package com.apress.servlet;

import javax.servlet.http.*;
import java.io.*;

public class BadServlet extends HttpServlet {
    public void doPost(HttpServletRequest req,
                     HttpServletResponse res)
      throws IOException
    {
  // Bad idea to wrap in try. Let exception get thrown, so web.xml's error-page tags can be processsed
  // (Unless you rethrow after logging!
  //    try {
        res.setContentType("text/html");
        PrintWriter writer = res.getWriter();
        writer.println("<html><head><title>Bad Servlet</title></head><body>");
        String num = req.getParameter("number");
        Integer i = new Integer(num);
        writer.println("You entered the number " + i.intValue());
        writer.println("</body></html>");
        writer.close();
   //   } catch (Exception e) {
   //     log("Exception in response", e);
   //   }
    }
}