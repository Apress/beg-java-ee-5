package com.apress.servlet;

import javax.servlet.http.*;
import java.io.*;

public class Calculator extends HttpServlet {
    private int result;
    private int sleepTime;

    public void init() {
      String sleep_time = getInitParameter("sleep.time");
      sleepTime = getNumber(sleep_time);
    }

    public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
    {
      String value1 = request.getParameter("value1");
      int v1 = getNumber(value1);
      String value2 = request.getParameter("value2");
      int v2 = getNumber(value2);
      String op = request.getParameter("submit");
      if ("Plus".equals(op)) {
        result = v1 + v2;
      } else {
        result = v1 - v2;
      }
      try {
        Thread.sleep(sleepTime);
      } catch (Exception e) {
        log("Exception during sleep", e);
      }
      try {
        response.setContentType("text/html");
        PrintWriter writer = response.getWriter();
        writer.println("<html><head><title>Calculated Answer</title></head><body>");
        writer.println(v1 + " " + op + " " + v2 + " is " + result);
        writer.println("</body></html>");
        writer.close();
      } catch (Exception e) {
        log("Error writing output", e);
      }
    }

    private int getNumber(String s) {
      int result = 0;
      try {
        result = Integer.parseInt(s);
      } catch (NumberFormatException e) {
         log("Error parsing '" + s + "'", e);         
      }
      return result;
    }
}