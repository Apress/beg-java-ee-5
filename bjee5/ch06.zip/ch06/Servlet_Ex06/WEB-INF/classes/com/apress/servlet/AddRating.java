package com.apress.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class AddRating extends HttpServlet {
  static final long serialVersionUID = -5489683351472970227L;
 
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
  {
     try {

       String analyst = request.getParameter("analysts");
       String ticker = request.getParameter("stocks");
       String rating = request.getParameter("ratings");

       Vector <String>v = new Vector<String>();
       v.add(analyst);
       v.add(ticker);
       v.add(rating);

       @SuppressWarnings("unchecked")
       ArrayList <Vector<String>>ratings = (ArrayList<Vector<String>>)request.getAttribute("data");
       ratings.add(v);

       ArrayList unratedStocks = 
         (ArrayList)request.getAttribute("unrated");
       unratedStocks.remove(unratedStocks.indexOf(ticker));

       ServletContext context = getServletContext();
       RequestDispatcher dispatcher =
         context.getNamedDispatcher("RatingsForm");
       dispatcher.forward(request, response);

     } catch (Exception e) {
       log("Exception in AddRating.DoPost()");
     }
 
  } 
}