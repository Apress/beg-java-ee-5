package beans;

import javax.ejb.Stateless;

@Stateless
public class SimpleSessionBean implements SimpleSession {
  public String getEchoString(String clientString) {
    return clientString + " - from session bean";
  }
}