package beans;

import javax.ejb.Remote;

@Remote
public interface StockList {
  // The public business methods on the StockList bean
  public void addStock(String ticker, String name)
    throws StockException;
  public void updateStock(String ticker, String name)
    throws StockException;
  public void deleteStock(String ticker)
    throws StockException;
  public String getStock(String ticker)
    throws StockException;
  public String[] getAllStocks();
  public String[] getSizeStocks(long siz);
}