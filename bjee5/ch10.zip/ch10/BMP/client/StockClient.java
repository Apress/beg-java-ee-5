package client;

import beans.StockList;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.InitialContext;

// General imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class StockClient extends JFrame
implements ActionListener {
  private StockList _stockList;
  private JTextField _ticker = new JTextField();
  private JTextField _name = new JTextField();
  private JButton _get  = new JButton("Get");
  private JButton _add  = new JButton("Add");
  private JButton _update = new JButton("Update");
  private JButton _delete = new JButton("Delete");

  public StockClient() {
    // Get the stock lister
    _stockList = getStockList();

    // Add the title
    JLabel title = new JLabel("Stock List");
    title.setHorizontalAlignment(JLabel.CENTER);
    getContentPane().add(title, BorderLayout.NORTH);

    // Add the stock label panel
    JPanel stockLabelPanel = new JPanel(new GridLayout(2, 1));
    stockLabelPanel.add(new JLabel("Symbol"));
    stockLabelPanel.add(new JLabel("Name"));
    getContentPane().add(stockLabelPanel, BorderLayout.WEST);

    // Add the stock field panel
    JPanel stockFieldPanel = new JPanel(new GridLayout(2, 1));
    stockFieldPanel.add(_ticker);
    stockFieldPanel.add(_name);
    getContentPane().add(stockFieldPanel, BorderLayout.CENTER);

    // Add the buttons
    JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
    _get.addActionListener(this);
    buttonPanel.add(_get);
    _add.addActionListener(this);
    buttonPanel.add(_add);
    _update.addActionListener(this);
    buttonPanel.add(_update);
    _delete.addActionListener(this);
    buttonPanel.add(_delete);
    getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });

    setSize(330, 130);
    setVisible(true);
  }

  private StockList getStockList() {
    StockList stockList = null;
    try {
    // Get a naming context
    InitialContext ctx = new InitialContext();

    // Get a StockList object
    stockList 
     = (StockList) ctx.lookup("StockListBean/remote");
    //  = (StockList) ctx.lookup(StockList.class.getName());
    } catch(Exception e) {
     e.printStackTrace();
    }
    return stockList;
  }

  public void actionPerformed(ActionEvent ae) {
    // If get was clicked, get the stock
    if (ae.getSource() == _get) {
      getStock();
    }

    // If add was clicked, add the stock
    if (ae.getSource() == _add) {
      addStock();
    }

    // If update was clicked, update the stock
    if (ae.getSource() == _update) {
      updateStock();
    }

    // If delete was clicked, delete the stock
    if (ae.getSource() == _delete) {
      deleteStock();
    }
  }

  private void getStock() {
    // Get the ticker
    String ticker = _ticker.getText();
    if (ticker == null || ticker.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Ticker is required");
      return;
    }

    // Get the stock
    try {
       String name = _stockList.getStock(ticker.trim());
      _name.setText(name);
    } catch (FinderException fe) {
      JOptionPane.showMessageDialog(this, "Not found!");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void addStock() {
    // Get the ticker
    String ticker = _ticker.getText();
    if (ticker == null || ticker.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Ticker is required");
      return;
    }

    // Get the name
    String name = _name.getText();
    if (name == null || name.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Name is required");
      return;
    }

    // Add the stock
    try {
      _stockList.addStock(ticker.trim(), name.trim());
      JOptionPane.showMessageDialog(this, "Stock added!");
    } catch (CreateException ce) {
      JOptionPane.showMessageDialog(this, "Already exists!");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void updateStock() {
    // Get the ticker
    String ticker = _ticker.getText();
    if (ticker == null || ticker.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Ticker is required");
      return;
    }

    // Get the name
    String name = _name.getText();
    if (name == null || name.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Name is required");
      return;
    }

    // Update the stock
    try {
      _stockList.updateStock(ticker.trim(), name.trim());
      JOptionPane.showMessageDialog(this, "Stock updated!");
    } catch (FinderException fe) {
      JOptionPane.showMessageDialog(this, "Not found!");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void deleteStock() {
    // Get the ticker
    String ticker = _ticker.getText();
    if (ticker == null || ticker.trim().length() == 0) {
      JOptionPane.showMessageDialog(this, "Ticker is required");
      return;
    }

    // Delete the stock
    try {
      _stockList.deleteStock(ticker.trim());
      JOptionPane.showMessageDialog(this, "Stock deleted!");
    } catch (FinderException fe) {
      JOptionPane.showMessageDialog(this, "Not found!");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {
    StockClient stockClient = new StockClient();
  }
}