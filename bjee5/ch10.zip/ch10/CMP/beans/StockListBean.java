package beans;

import beans.Stock;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;

@Stateless
public class StockListBean implements StockList {

  // The reference to the entity manager
  @PersistenceContext(unitName="stkcmp")
  private EntityManager _manager;

  // The public business methods. These must be coded in the
  // remote interface also

  public String getStock(String ticker) throws StockException {
     Stock stock = _manager.find(Stock.class, ticker);
     if (stock == null) {
       throw new StockException();
     }
     return stock.getName();
  }

  public void addStock(String ticker, String name) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock != null) {
      throw new StockException();
    }
    _manager.persist(new Stock(ticker, name));
  }

  public void updateStock(String ticker, String name) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    stock.setName(name);
  }

  public void deleteStock(String ticker) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    _manager.remove(stock);
  }
}