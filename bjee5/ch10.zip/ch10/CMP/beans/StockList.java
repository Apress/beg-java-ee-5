package beans;

import javax.ejb.Remote;

@Remote
public interface StockList {
  // The public business methods on the StockList bean
  public String getStock(String ticker)
    throws StockException;
  public void addStock(String ticker, String name)
    throws StockException;
  public void updateStock(String ticker, String name)
    throws StockException;
  public void deleteStock(String ticker)
    throws StockException;
}