package transfer;

import java.io.Serializable;

public class StockTO implements Serializable {

  static final long serialVersionUID = -7569415178705811306L;

  // Holds references to the attribute data
  private String tickerSymbol;
  private String name;
  private String rating;

  // Holds referencess to the relationships
  private AnalystTO analyst;

  public StockTO(String tickerSymbol, String name, String rating) {
    this.tickerSymbol = tickerSymbol; 
    this.name = name;
    this.rating = rating;
    analyst = null;
  }

  // Get ticker symbol. No setter because primary key
  public String getTickerSymbol() {
    return tickerSymbol;
  }

  // Get, set name
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  // Get, set rating
  public String getRating() {
    return rating;
  }

  public void setRating(String rating) {
    this.rating = rating;
  }

  // Get, set analyst
  public AnalystTO getAnalyst() {
    return analyst;
  }

  public void setAnalyst(AnalystTO analyst) {
    this.analyst = analyst;
    this.analyst.getStocks().add(this);
  }
}
