package transfer;

import java.io.Serializable;
import java.util.*;

public class AnalystTO implements Serializable {
  static final long serialVersionUID = 5580964659685200895L;
  // Holds references to the attribute data
  private Integer analystId;
  private String name;

  // Holds references to the relationships
  private List <StockTO>stocks;

  public AnalystTO(Integer analystId, String name) {
    this.analystId = analystId; 
    this.name = name;
    stocks = new ArrayList<StockTO>();
  }

  // Get analyst id. No setter because primary key
  public Integer getAnalystId() {
    return analystId;
  }

  // Get, set name
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List <StockTO>getStocks() {
    return stocks;
  }
}