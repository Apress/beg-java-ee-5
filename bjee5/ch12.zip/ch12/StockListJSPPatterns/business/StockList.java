// Session Bean Interface

package business;

import javax.ejb.Remote;
import transfer.AnalystTO;
import transfer.StockTO;

// General imports
import java.util.*;

@Remote
public interface StockList {
  // The public business methods on the StockList bean
  public List <StockTO>getStockRatings();
  public List <AnalystTO>getAllAnalysts();
  public List <StockTO>getUnratedStocks();
  public void addStockRating(StockTO stockTO);
  public void addAnalyst(AnalystTO analystTO);
  public void addStock(StockTO stockTO);
}