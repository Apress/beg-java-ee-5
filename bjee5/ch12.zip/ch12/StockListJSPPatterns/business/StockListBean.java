// Session Bean Implementation of StockList Interface

package business;


import dao.AnalystDAO;
import dao.StockDAO;
import dao.StockListDAO;
import dao.StockListDAOFactory;
import transfer.AnalystTO;
import transfer.StockTO;
import javax.ejb.Stateless;

// General imports
import java.util.*;

@Stateless
public class StockListBean implements StockList {
  // The public business methods. These must be coded in the
  // StockList remote interface also

  public List <StockTO>getStockRatings() {
    List <StockTO>stockList= new ArrayList<StockTO>();

    // get the rated stocks
    StockListDAO dao = StockListDAOFactory.getStockListDAO();
    List <StockDAO>stocks = dao.getRatedStocks();
    for (int i = 0; i < stocks.size(); i++) {
      StockDAO stock = stocks.get(i);
      StockTO stockTO = new StockTO(stock.getTickerSymbol(), 
        stock.getName(), stock.getRating());
      AnalystDAO analyst = stock.getAnalyst();
      AnalystTO analystTO = new AnalystTO(analyst.getAnalystId(), 
        analyst.getName());
      stockTO.setAnalyst(analystTO);
      stockList.add(stockTO);
    }
    return stockList;
  }

  public List <AnalystTO>getAllAnalysts() {
    List <AnalystTO>analystList= new ArrayList<AnalystTO>();

    // get the analysts
    StockListDAO dao = StockListDAOFactory.getStockListDAO();
    List <AnalystDAO>analysts = dao.getAnalysts();
    for (int i = 0; i < analysts.size(); i++) {
      AnalystDAO analyst = analysts.get(i);
      AnalystTO analystTO = new AnalystTO(analyst.getAnalystId(), 
        analyst.getName());
      analystList.add(analystTO);
    }
    return analystList;
  }

  public List <StockTO>getUnratedStocks() {
    List <StockTO>stockList= new ArrayList<StockTO>();

    // get the unrated stocks
    StockListDAO dao = StockListDAOFactory.getStockListDAO();
    List <StockDAO>stocks = dao.getUnratedStocks();
    for (int i = 0; i < stocks.size(); i++) {
      StockDAO stock = stocks.get(i);
      StockTO stockTO = new StockTO(stock.getTickerSymbol(), 
        stock.getName(), stock.getRating());
      stockList.add(stockTO);
    }
    return stockList;
  }

  public void addStockRating(StockTO stockTO) {
    StockListDAO dao = StockListDAOFactory.getStockListDAO();
    dao.rateStock(stockTO.getTickerSymbol(), 
                  stockTO.getAnalyst().getAnalystId(), 
                  stockTO.getRating());
  }

  public void addAnalyst(AnalystTO analystTO) {
    StockListDAO dao = StockListDAOFactory.getStockListDAO();
    AnalystDAO analyst = new AnalystDAO();
    analyst.setAnalystId(analystTO.getAnalystId());
    analyst.setName(analystTO.getName());
    dao.addAnalyst(analyst);
  }

  public void addStock(StockTO stockTO) {
    StockListDAO dao = StockListDAOFactory.getStockListDAO();
    StockDAO stock = new StockDAO();
    stock.setTickerSymbol(stockTO.getTickerSymbol());
    stock.setName(stockTO.getName());
    dao.addStock(stock);
  }
}