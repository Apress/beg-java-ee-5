// Used by client to make a connection to the session bean

package delegate;

import business.StockList;
import transfer.AnalystTO;
import transfer.StockTO;

import javax.naming.InitialContext;

// General imports
import java.util.*;

public class StockListDelegate {
  // Reference to singleton delegate
  private static StockListDelegate stockListDelegate;

  // The reference to the StockList Session bean
  private StockList stockList;

  // private constructor - makes connection to session bean
  private StockListDelegate() throws StockListException {
    try {
      // Get a naming context
      InitialContext ctx = new InitialContext();

      // Get a StockList object
      stockList = 
        (StockList) ctx.lookup("StockListBean/remote");
    } catch (Exception e) {
      throw new StockListException(e.getMessage());
    }
  }

  // The business methods. No exposure to actual implementation
  // on the server, and the communication method between client and
  // server is hidden to the client.

  public List <StockTO>getStockRatings() throws StockListException {
    try {
      List <StockTO>ratings = stockList.getStockRatings();
      return ratings;
    } catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public List <AnalystTO>getAllAnalysts() throws StockListException {
    try {
      List <AnalystTO>analysts = stockList.getAllAnalysts();
      return analysts;
    } catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public List <StockTO>getUnratedStocks() throws  StockListException {
    try {
      List <StockTO>stocks = stockList.getUnratedStocks();
      return stocks;
    } catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public void addStockRating(StockTO stock)
    throws StockListException {
    try {
      stockList.addStockRating(stock);
    } catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }
   
  public void addAnalyst(AnalystTO analyst)
    throws StockListException {
    try {
      stockList.addAnalyst(analyst);
    } catch (Exception re) {
      // throw new StockListException(re.getMessage());
      re.printStackTrace();
    }
  }

  public void addStock(StockTO stock)
    throws StockListException {
    try {
      stockList.addStock(stock);
    } catch (Exception re) {
      throw new StockListException(re.getMessage());
    }
  }

  public static StockListDelegate getInstance()
    throws StockListException {
    if (stockListDelegate == null) {
      stockListDelegate = new StockListDelegate();
    }
    return stockListDelegate;
  }
} 