// Used by client to make a connection to the session bean

package delegate;

public class StockListException extends Exception {
  static final long serialVersionUID = -5947544866993392422L;
  public StockListException(String msg) {
    super(msg);
  }
}