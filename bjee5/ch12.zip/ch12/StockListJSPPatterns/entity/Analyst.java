package entity;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Id;

import java.io.Serializable;
import java.util.*;

// Entity Bean

@Entity
public class Analyst implements Serializable {
  static final long serialVersionUID = 1057249437610223386L;
  // The persistent fields
  private Integer analystId;
  private String name;

  // The cmr fields
  private Collection<Stock> stocks;

  // Constructors
  public Analyst() {}
  public Analyst(Integer analystId, String name) {
    this.analystId = analystId;
    this.name = name;
  }

  // The access methods for persistent fields
  @Id
  public Integer getAnalystId() {
    return analystId;
  }

  public void setAnalystId(Integer analystId) {
    this.analystId = analystId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  // The access methods for cmr fields
  @OneToMany(mappedBy="analyst")
  public Collection<Stock> getStocks() {
    return stocks;
  }

  public void setStocks(Collection<Stock> stocks) {
    this.stocks = stocks;
  }

  // Business methods
  public void assignStock(Stock stock) {
    if (stocks == null) {
       stocks = new ArrayList<Stock>();
    }
    stock.setAnalyst(this);
    stocks.add(stock);
  }
}