package dao;

import javax.naming.InitialContext;

public class StockListDAOFactory {
  public static StockListDAO getStockListDAO() {
    // This is a simple implementation of a
    // factory. If other implementations of
    // the dao interface are needed, this
    // method can be changed to get the
    // appropriate implementation.

    try {
      // get a naming context
      InitialContext ctx = new InitialContext();

      // Get a StockListDAO object
      StockListDAO stockListDAO =
        (StockListDAO) ctx.lookup("Ejb3StockListDAOBean/remote");
      return stockListDAO;
    } catch (Exception e) {
      throw new RuntimeException(e.getMessage());
    }
  }
}