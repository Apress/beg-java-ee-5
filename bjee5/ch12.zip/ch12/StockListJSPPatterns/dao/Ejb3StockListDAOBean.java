package dao;

import entity.Analyst;
import entity.Stock;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import java.util.*;

@Stateless
public class Ejb3StockListDAOBean implements Ejb3StockListDAO {
  // The reference to the entity manager
  @PersistenceContext(unitName="stkcmp")
  private EntityManager _manager;

  public List <StockDAO>getRatedStocks() {
    Query query =
      _manager.createQuery("SELECT DISTINCT OBJECT(s) " +
                           "FROM Stock s " +
                           "WHERE s.analyst IS NOT NULL " +
                           "ORDER BY s.tickerSymbol");
    // Get the rated stocks
    List stocks = query.getResultList();
    List <StockDAO>stockList = new ArrayList<StockDAO>();
    for (int i = 0; i < stocks.size(); i++) {
      Stock stockBean = (Stock) stocks.get(i);
      StockDAO stock = new StockDAO();
      stock.setTickerSymbol(stockBean.getTickerSymbol());
      stock.setName(stockBean.getName());
      stock.setRating(stockBean.getRating());
      Analyst analystBean = stockBean.getAnalyst();
      AnalystDAO analyst = new AnalystDAO();
      analyst.setAnalystId(analystBean.getAnalystId());
      analyst.setName(analystBean.getName());
      stock.setAnalyst(analyst);
      stockList.add(stock);
    }

    return stockList;
  }

  public List <AnalystDAO>getAnalysts() {
    Query query =
      _manager.createQuery("SELECT OBJECT(a) " +
                           "FROM Analyst a " +
                           "ORDER BY a.name");
    // Get the analysts
    List analysts = query.getResultList();
    List <AnalystDAO>analystList = new ArrayList<AnalystDAO>();
    for (int i = 0; i < analysts.size(); i++) {
      Analyst analystBean = (Analyst) analysts.get(i);
      AnalystDAO analyst = new AnalystDAO();
      analyst.setAnalystId(analystBean.getAnalystId());
      analyst.setName(analystBean.getName());
      analystList.add(analyst);
    }

    return analystList;
  }

  public List <StockDAO>getUnratedStocks() {
    Query query =
      _manager.createQuery("SELECT DISTINCT OBJECT(s) " +
                           "FROM Stock s " +
                           "WHERE s.analyst IS NULL " +
                           "ORDER BY s.tickerSymbol");
    // Get the unrated stocks
    List stocks = query.getResultList();
    List <StockDAO>stockList = new ArrayList<StockDAO>();
    for (int i = 0; i < stocks.size(); i++) {
      Stock stockBean = (Stock) stocks.get(i);
      StockDAO stock = new StockDAO();
      stock.setTickerSymbol(stockBean.getTickerSymbol());
      stock.setName(stockBean.getName());
      stockList.add(stock);
    }

    return stockList;
  }

  public void rateStock(String ticker, Integer analystId, 
    String rating) {
    Stock stock = _manager.find(Stock.class, ticker);
    Analyst analyst = _manager.find(Analyst.class, analystId);
    analyst.assignStock(stock);
    stock.setRating(rating);
  }

  public void addAnalyst(AnalystDAO analyst) {
    _manager.persist(
      new Analyst(analyst.getAnalystId(), analyst.getName()));
  }

  public void addStock(StockDAO stock) {
    _manager.persist(
      new Stock(stock.getTickerSymbol(), stock.getName()));
  }

}