package dao;

import java.io.Serializable;

public class StockDAO implements Serializable {
  static final long serialVersionUID = -2829162115847837425L;
  // Holds references to the attribute data
  private String tickerSymbol;
  private String name;
  private String rating;

  // Relationship attributes
  private AnalystDAO analyst;

  public String getTickerSymbol() {
    return tickerSymbol;
  }

  public void setTickerSymbol(String tickerSymbol) {
    this.tickerSymbol = tickerSymbol;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getRating() {
    return rating;
  }

  public void setRating(String rating) {
    this.rating = rating;
  }

  public AnalystDAO getAnalyst() {
    return analyst;
  }

  public void setAnalyst(AnalystDAO analyst) {
    this.analyst = analyst;
  }
}