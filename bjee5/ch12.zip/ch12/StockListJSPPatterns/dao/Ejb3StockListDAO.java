package dao;

import javax.ejb.Remote;

@Remote
public interface Ejb3StockListDAO extends StockListDAO {}
