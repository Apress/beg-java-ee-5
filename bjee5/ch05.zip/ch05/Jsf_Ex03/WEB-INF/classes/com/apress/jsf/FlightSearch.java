package com.apress.jsf;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import javax.faces.context.FacesContext;

public class FlightSearch {
  // properties :
  // origination, destination, departDate, departTime
  // returnDate, returnTime, tripType, matchingFlights same again..
  String origination;
  String destination;
  String departDate;
  String departTime;
  String returnDate;
  String returnTime;
  String tripType;
  ArrayList <Flight>matchingFlights = new ArrayList<Flight>();

  // new properties
  String flightNum;
  Flight matchingFlight;

  // new methods are reset(), search(), and
  // get/set methods for flightNum/matchingFight

  public String reset() {
    this.setDepartDate("");
    this.setDepartTime("");
    this.setDestination("");
    this.setOrigination("");
    this.setReturnDate("");
    this.setReturnTime("");
    this.setTripType("");
    return "success";
  }

  public String search() {
    if (origination.equals("BOS") && destination.equals("ORD")) {
      return "success";
    } else {
      return "no flights";
    }
  }
  
  public Flight getMatchingFlight() {
    for (int i = 0; i < matchingFlights.size(); i++) {
      matchingFlight = matchingFlights.get(i);
      if (matchingFlight.flightNum.equals(flightNum)) {
        break;
      }
      matchingFlight = null;
    }
    return matchingFlight;
  }

  public void setMatchingFlight(Flight flight) {
    matchingFlight = flight;
  }
  
  public String getFlightNum() {
    return flightNum;
  }

  public void setFlightNum(String flightNum) {
    this.flightNum = flightNum;
  }

  public String select() {
    FacesContext context = FacesContext.getCurrentInstance();
    Map requestParams = 
      context.getExternalContext().getRequestParameterMap();
    flightNum = (String) requestParams.get("flightNum");
    return "select";
  }

  public String getDepartDate() {
    return departDate;
  }

  public void setDepartDate(String departDate) {
    this.departDate = departDate;
    matchingFlights.get(0).setDepartDate(departDate);
    matchingFlights.get(1).setDepartDate(departDate);
  }

  public String getDepartTime() {
    return departTime;
  }

  public void setDepartTime(String departTime) {
    this.departTime = departTime;
    matchingFlights.get(0).setDepartTime(departTime);
    matchingFlights.get(1).setDepartTime(departTime);
  }

 public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
    matchingFlights.get(0).setDestination(destination);
    matchingFlights.get(1).setDestination(destination);
    matchingFlights.get(0).setFlightNum("133");
    matchingFlights.get(1).setFlightNum("233");

  }

 public String getOrigination() {
    return origination;
  }

  public void setOrigination(String origination) {
    this.origination = origination;
    matchingFlights.get(0).setOrigination(origination);
    matchingFlights.get(1).setOrigination(origination);
  }

 public String getReturnDate() {
    return returnDate;
  }

  public void setReturnDate(String returnDate) {
    this.returnDate = returnDate;
    matchingFlights.get(0).setReturnDate(returnDate);
    matchingFlights.get(1).setReturnDate(returnDate);
  }

 public String getReturnTime() {
    return returnTime;
  }

  public void setReturnTime(String returnTime) {
    this.returnTime = returnTime;
    matchingFlights.get(0).setReturnTime(returnTime);
    matchingFlights.get(1).setReturnTime(returnTime);

  }

  public String getTripType() {
    return tripType;
  }

  public void setTripType(String tripType) {
    this.tripType= tripType;
  }

  public List<Flight> getMatchingFlights() {
    return matchingFlights;
  }

  public void setMatchingFlights(List<Flight> matchingFlights) {
    this.matchingFlights.addAll(matchingFlights);
  }
} 