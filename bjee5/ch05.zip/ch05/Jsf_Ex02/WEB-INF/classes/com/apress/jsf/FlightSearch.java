package com.apress.jsf;

import java.util.List;
import java.util.ArrayList;

public class FlightSearch {
  String origination;
  String destination;
  String departDate;
  String departTime;
  String returnDate;
  String returnTime;
  String tripType;
  ArrayList <Flight>matchingFlights = new ArrayList<Flight>();

  public String getDepartDate() {
    return departDate;
  }

  public void setDepartDate(String departDate) {
    this.departDate = departDate;
    matchingFlights.get(0).setDepartDate(departDate);
    matchingFlights.get(1).setDepartDate(departDate);
  }

  public String getDepartTime() {
    return departTime;
  }

  public void setDepartTime(String departTime) {
    this.departTime = departTime;
    matchingFlights.get(0).setDepartTime(departTime);
    matchingFlights.get(1).setDepartTime(departTime);
  }

 public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
    matchingFlights.get(0).setDestination(destination);
    matchingFlights.get(1).setDestination(destination);
    matchingFlights.get(0).setFlightNum("133");
    matchingFlights.get(1).setFlightNum("233");

  }

 public String getOrigination() {
    return origination;
  }

  public void setOrigination(String origination) {
    this.origination = origination;
    matchingFlights.get(0).setOrigination(origination);
    matchingFlights.get(1).setOrigination(origination);
  }

 public String getReturnDate() {
    return returnDate;
  }

  public void setReturnDate(String returnDate) {
    this.returnDate = returnDate;
    matchingFlights.get(0).setReturnDate(returnDate);
    matchingFlights.get(1).setReturnDate(returnDate);
  }

 public String getReturnTime() {
    return returnTime;
  }

  public void setReturnTime(String returnTime) {
    this.returnTime = returnTime;
    matchingFlights.get(0).setReturnTime(returnTime);
    matchingFlights.get(1).setReturnTime(returnTime);

  }

  public String getTripType() {
    return tripType;
  }

  public void setTripType(String tripType) {
    this.tripType= tripType;
  }

  public List<Flight> getMatchingFlights() {
    return matchingFlights;
  }

  public void setMatchingFlights(List<Flight> matchingFlights) {
    this.matchingFlights.addAll(matchingFlights);
  }
} 