package beans;

import javax.ejb.Remote;

// General imports
import java.util.*;

@Remote
public interface StockList {
  // The public business methods on the StockList bean
  public List getStockRatings();
  public List getAllAnalysts();
  public List getUnratedStocks();
  public void addStockRating(String ticker, Integer analystId, 
    String rating) throws StockException, AnalystException;
  public void addAnalyst(Integer id, String name)
    throws AnalystException;
  public void addStock(String ticker, String name)
    throws StockException;
  public void updateStock(String ticker, String name)
    throws StockException;
  public void deleteStock(String ticker)
    throws StockException;
  public String getStock(String ticker)
    throws StockException;
  public String[] getAllStocks();
  public String[] getSizeStocks(long siz);
  
}