package beans;

public class AnalystException extends Exception {
  static final long serialVersionUID = -2624893989925190722L;
  public AnalystException() {
    super();
  }

  public AnalystException(String msg) {
    super(msg);
  }
}