package beans;

public class StockException extends Exception {
  static final long serialVersionUID = -8073933666791502432L;
  public StockException() {
    super();
  }

  public StockException(String msg) {
    super(msg);
  }
}