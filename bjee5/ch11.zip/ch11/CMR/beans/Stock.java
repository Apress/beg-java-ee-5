package beans;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Id;

import java.io.Serializable;

// Entity bean

@Entity
public class Stock implements Serializable {
  static final long serialVersionUID = -1576770838941908715L;
  // The persistent fields
  private String tickerSymbol;
  private String name;
  private String rating;
  // The cmr fields
  private Analyst analyst;

  // Constructors
  public Stock() {}
  public Stock(String tickerSymbol, String name) {
    this.tickerSymbol = tickerSymbol;
    this.name = name;
    this.rating = null;
  }

  // The access methods for persistent fields
  // tickerSymbol is the id
  @Id
  public String getTickerSymbol() {
    return tickerSymbol;
  }

  public void setTickerSymbol(String tickerSymbol) {
    this.tickerSymbol = tickerSymbol;
  }

  public String getName() {
     return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getRating() {
     return rating;
  }

  public void setRating(String rating){
    this.rating = rating;
  }

  // The access methods for cmr fields
  @ManyToOne
  public Analyst getAnalyst() {
    return analyst;
  }

  public void setAnalyst(Analyst analyst) {
    this.analyst = analyst;
  }
}