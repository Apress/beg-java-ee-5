package beans;

import beans.Stock;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

// General imports
import java.util.*;

// This is a session bean

@Stateless
public class StockListBean implements StockList {

  // The reference to the entity manager
  @PersistenceContext(unitName="stkcmp")
  private EntityManager _manager;

  // The public business methods. These must be coded in the
  // remote interface also

  public List <String []>getStockRatings() {
    List <String []>stkList = new ArrayList<String []>();
    Query query =
      _manager.createQuery("SELECT DISTINCT OBJECT(s) " +
                           "FROM Stock s " +
                           "WHERE s.analyst IS NOT NULL " +
                           "ORDER BY s.tickerSymbol");
    List stocks = query.getResultList();
    for (int i = 0; i < stocks.size(); i++) {
      Stock stock = (Stock) stocks.get(i);
      String [] stockData = new String[4];
      stockData[0] = stock.getTickerSymbol();
      stockData[1] = stock.getName();
      stockData[2] = stock.getAnalyst().getName();
      stockData[3] = stock.getRating();
      stkList.add(stockData); 
    }
    return stkList;
  }

  public List <Object []>getAllAnalysts() {
    List <Object []>analystList = new ArrayList<Object []>();
    Query query =
      _manager.createQuery("SELECT OBJECT(a) " +
                           "FROM Analyst a " +
                           "ORDER BY a.name");
    List analysts = query.getResultList();
    for (int i = 0; i < analysts.size(); i++) {
      Analyst analyst= (Analyst) analysts.get(i);
      Object [] analystData = new Object[2];
      analystData[0] = analyst.getAnalystId();
      analystData[1] = analyst.getName();
      analystList .add(analystData); 
    }
    return analystList;

  }

  public List <String>getUnratedStocks() {
    List <String>stkList = new ArrayList<String>();
    Query query =
      _manager.createQuery("SELECT DISTINCT OBJECT(s) " +
                           "FROM Stock s " +
                           "WHERE s.analyst IS NULL " +
                           "ORDER BY s.tickerSymbol");
    List stocks = query.getResultList();
    for (int i = 0; i < stocks.size(); i++) {
      Stock stock = (Stock) stocks.get(i);
      stkList.add(stock.getTickerSymbol()); 
    }
    return stkList;
  }

  public void addStockRating(String ticker, Integer analystId, String rating) 
    throws StockException, AnalystException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    Analyst analyst = _manager.find(Analyst.class, analystId);
    if (analyst == null) {
      throw new AnalystException();
    }
    analyst.assignStock(stock);
    stock.setRating(rating);
  }

  public void addAnalyst(Integer id, String name) throws AnalystException {
    Analyst analyst = _manager.find(Analyst .class, id);
    if (analyst != null) {
      throw new AnalystException();
    }
    _manager.persist(new Analyst (id, name));
  }

  public String getStock(String ticker) throws StockException {
     Stock stock = _manager.find(Stock.class, ticker);
     if (stock == null) {
       throw new StockException();
     }
     return stock.getName();
  }

  public void addStock(String ticker, String name) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock != null) {
      throw new StockException();
    }
    _manager.persist(new Stock(ticker, name));
  }

  public void updateStock(String ticker, String name) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    stock.setName(name);
  }

  public void deleteStock(String ticker) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    _manager.remove(stock);
  }

  // The finder methods
  public String[] getAllStocks() {
    Query query = 
      _manager.createQuery("SELECT s FROM Stock s " +
                           "ORDER BY s.tickerSymbol");
    List stockList = query.getResultList();
    String[] stocks = new String[stockList.size()];
    int j = 0;
    for (int i = 0; i < stockList.size(); i++) {
      Stock stock = (Stock) stockList.get(i);
      stocks[j++] = stock.getTickerSymbol();
    }
    return stocks;
  }

  public String[] getSizeStocks(long siz) {
    Query query =
      _manager.createQuery("SELECT s FROM Stock s " +
                           "WHERE LENGTH(s.tickerSymbol) = :len " +
                           "ORDER BY s.tickerSymbol");
    query.setParameter("len", siz);
    List stockList = query.getResultList();
    String[] stocks = new String[stockList.size()];
    int j = 0;
    for (int i = 0; i < stockList.size(); i++) {
      Stock stock = (Stock) stockList.get(i);
      stocks[j++] = stock.getTickerSymbol();
    }
    return stocks;
  }
}