package client;

import beans.StockList;
import javax.naming.InitialContext;

public class StockListAdder {
  private StockList _stockList;

  public StockListAdder() {
    try {
      _stockList = getStockList();
    } catch (Exception e) {
      System.out.println("exception doing JNDI lookup");
      e.printStackTrace();
    }

    try {
      // Add analysts
      System.out.println("adding analysts");
      _stockList.addAnalyst(new Integer(1), "Fred");
      _stockList.addAnalyst(new Integer(2), "Leonard");
      _stockList.addAnalyst(new Integer(3), "Sarah");
      _stockList.addAnalyst(new Integer(4), "Nancy");
    System.out.println("analysts added");
    } catch (Exception e) {
      System.out.println("exception adding analysts");
      e.printStackTrace();
    }

    try {
      // Adding stocks
      System.out.println("adding stocks");
      _stockList.addStock("ABC", "ABC Company");
      _stockList.addStock("ZZZ", "Zigby Zebras");
      _stockList.addStock("ICS", "Internet Corp of Slobovia");
      _stockList.addStock("DDC", "Digby Door Company");
      _stockList.addStock("ZAP", "Zapalopaorinksi Ltd.");
      _stockList.addStock("JIM", "Jimco");
      _stockList.addStock("SRU", "Stocks R Us");
      _stockList.addStock("SRI", "Shelves and Radios Inc");
      _stockList.addStock("FBC", "Foo Bar Company");
      _stockList.addStock("DDBC", "Ding Dong Bell Company");
       _stockList.addStock("UDE", "Upn Down Elevator Company");
      System.out.println("stocks added");
    } catch (Exception e) {
      System.out.println("exception adding stocks");
      e.printStackTrace();
    }

    try {
      // Add ratings
      System.out.println("adding ratings");
      _stockList.addStockRating("ZZZ", new Integer(2), "Take a chance!");
      System.out.println("ratings added");
    } catch (Exception e) {
      System.out.println("exception adding ratings");
      e.printStackTrace();
    }
  }

  private StockList getStockList() {
    StockList stockList = null;
    try {
      // Get a naming context
      InitialContext ctx = new InitialContext();

      // Get a StockList object
      stockList 
        = (StockList) ctx.lookup("StockListBean/remote");
    } catch(Exception e) {
      e.printStackTrace();
    }
    return stockList;
  }

  public static void main(String[] args) {
    StockListAdder stockListAdder = new StockListAdder();       
  }
}