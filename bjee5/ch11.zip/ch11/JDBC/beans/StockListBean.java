package beans;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

import beans.Stock;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.sql.DataSource;

// General imports
import java.util.*;

// This is a session bean

@Stateless
public class StockListBean implements StockList {

  // The reference to the entity manager
  @PersistenceContext(unitName="stkcmp")
  private EntityManager _manager;

  // The public business methods. These must be coded in the
  // remote interface also

  public List <String []>getStockRatings() {
    List <String []>stkList = new ArrayList<String []>();
    Query query =
      _manager.createQuery("SELECT DISTINCT OBJECT(s) " +
                           "FROM Stock s " +
                           "WHERE s.analyst IS NOT NULL " +
                           "ORDER BY s.tickerSymbol");
    List stocks = query.getResultList();
    for (int i = 0; i < stocks.size(); i++) {
      Stock stock = (Stock) stocks.get(i);
      String [] stockData = new String[4];
      stockData[0] = stock.getTickerSymbol();
      stockData[1] = stock.getName();
      stockData[2] = stock.getAnalyst().getName();
      stockData[3] = stock.getRating();
      stkList.add(stockData); 
    }
    return stkList;
  }

  public List <Object []>getAllAnalysts() {
    try {
      // Make the sql
      StringBuffer sql = new StringBuffer();
      sql.append("SELECT analystId, name ");
      sql.append("FROM Analyst ");
      sql.append("ORDER BY name");

      // Get the db connection, statement and result set
      Connection conn = makeConnection();
      Statement stmt = conn.createStatement();
      ResultSet results = stmt.executeQuery(sql.toString());

      // Get the analysts
      List <Object []>analystList = new ArrayList<Object []>();
      while (results.next()) {
        Object [] analystData = new Object[2];
        analystData[0] = new Integer(results.getInt(1));
        analystData[1] = results.getString(2);
        analystList .add(analystData); 
      }

      results.close();
      stmt.close();
      conn.close();

      return analystList;

    } catch (Exception ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }

  public List <String>getUnratedStocks() {
    List <String>stkList = new ArrayList<String>();
    Query query =
      _manager.createQuery("SELECT DISTINCT OBJECT(s) " +
                           "FROM Stock s " +
                           "WHERE s.analyst IS NULL " +
                           "ORDER BY s.tickerSymbol");
    List stocks = query.getResultList();
    for (int i = 0; i < stocks.size(); i++) {
      Stock stock = (Stock) stocks.get(i);
      stkList.add(stock.getTickerSymbol()); 
    }
    return stkList;
  }

  public void addStockRating(String ticker, Integer analystId, String rating) 
    throws StockException, AnalystException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    Analyst analyst = _manager.find(Analyst.class, analystId);
    if (analyst == null) {
      throw new AnalystException();
    }
    analyst.assignStock(stock);
    stock.setRating(rating);
  }

  public void addAnalyst(Integer id, String name) throws AnalystException {
    Analyst analyst = _manager.find(Analyst .class, id);
    if (analyst != null) {
      throw new AnalystException();
    }
    _manager.persist(new Analyst (id, name));
  }

  public String getStock(String ticker) throws StockException {
     Stock stock = _manager.find(Stock.class, ticker);
     if (stock == null) {
       throw new StockException();
     }
     return stock.getName();
  }

  public void addStock(String ticker, String name) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock != null) {
      throw new StockException();
    }
    _manager.persist(new Stock(ticker, name));
  }

  public void updateStock(String ticker, String name) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    stock.setName(name);
  }

  public void deleteStock(String ticker) throws StockException {
    Stock stock = _manager.find(Stock.class, ticker);
    if (stock == null) {
      throw new StockException();
    }
    _manager.remove(stock);
  }

  // The finder methods
  public String[] getAllStocks() {
    Query query = 
      _manager.createQuery("SELECT s FROM Stock s " +
                           "ORDER BY s.tickerSymbol");
    List stockList = query.getResultList();
    String[] stocks = new String[stockList.size()];
    int j = 0;
    for (int i = 0; i < stockList.size(); i++) {
      Stock stock = (Stock) stockList.get(i);
      stocks[j++] = stock.getTickerSymbol();
    }
    return stocks;
  }

  public String[] getSizeStocks(long siz) {
    Query query =
      _manager.createQuery("SELECT s FROM Stock s " +
                           "WHERE LENGTH(s.tickerSymbol) = :len " +
                           "ORDER BY s.tickerSymbol");
    query.setParameter("len", siz);
    List stockList = query.getResultList();
    String[] stocks = new String[stockList.size()];
    int j = 0;
    for (int i = 0; i < stockList.size(); i++) {
      Stock stock = (Stock) stockList.get(i);
      stocks[j++] = stock.getTickerSymbol();
    }
    return stocks;
  }

  private Connection makeConnection()
    throws NamingException, SQLException {

    InitialContext ic = new InitialContext();
    DataSource ds = 
      (DataSource) ic.lookup("java:/DefaultDS");
   return ds.getConnection();
  }
}