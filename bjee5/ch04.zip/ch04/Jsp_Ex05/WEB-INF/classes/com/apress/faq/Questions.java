package com.apress.faq;

import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;

public class Questions {
  private String topic;
  private int numQuestions;
  private Map<String, Map<String, String>> questions = new HashMap<String, Map<String, String>>();

  public String getTopic() { return topic; }
  public void setTopic(String t) {
    topic = t;
    setNumQuestions(getQuestions().size());
  }

  public int getNumQuestions() { return numQuestions; }
  public void setNumQuestions(int n) { numQuestions = n ; }

  public Map getQuestions() {
    return questions.get(topic);
  }
  public void setQuestions(Map<String, Map<String, String>> m) { questions = m; }

  public Questions() {
   Map<String, String> topic = new TreeMap<String, String>();
   topic.put("EL_1","How do I use implicit objects?");
   topic.put("EL_2","How do I use the JSTL?");
   topic.put("EL_3","How do I use the 'empty' operator?");
   questions.put("EL", topic);
   topic = new TreeMap<String, String>();
   questions.put("JSTL", topic);   
  }
}