package com.apress.faq;

import java.util.*;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;

public class ListQuestionsInBody extends BodyTagSupport {
  private String topic;
  private Iterator qids;
  private Map qmap;

  public void setTopic(String s) { topic = s; }

  public int doStartTag() throws JspException {
    Questions questions = new Questions();
    questions.setTopic(topic);
    qmap = questions.getQuestions();
    qids = qmap.keySet().iterator();

    if (qids.hasNext()) {
      Object qid = qids.next();
      setVariables(qid, qmap.get(qid));
      return EVAL_BODY_INCLUDE;
    } else {
      return SKIP_BODY;
    }
  }

  public int doAfterBody() throws JspException {
    if (qids.hasNext()) {
      Object key = qids.next();
      setVariables(key, qmap.get(key));
      return EVAL_BODY_BUFFERED;
    } else {
      return SKIP_BODY;
    }
  }

  public int doEndTag() throws JspException {
    return EVAL_PAGE;
  }
  void setVariables(Object key, Object value) {
    pageContext.setAttribute("question", value);
    pageContext.setAttribute("qid", key);
  }
}