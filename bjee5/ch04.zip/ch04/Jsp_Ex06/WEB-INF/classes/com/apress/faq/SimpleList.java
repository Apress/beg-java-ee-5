package com.apress.faq;

import java.util.*;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;

public class SimpleList extends SimpleTagSupport {
  private String topic;
  public void setTopic(String s) { topic = s; }
  public String getTopic() { return topic; }

  public void doTag() throws JspException {
    Questions questions = new Questions();
    questions.setTopic(topic);

   // Get list of questions and the iterator for the keys
   Map qmap = questions.getQuestions();
   Iterator keys = qmap.keySet().iterator();

   while (keys.hasNext()) {
     try {
       Object key = keys.next();
       // Store the parameter for invoke()
       getJspContext().setAttribute("qid", key);
       getJspContext().setAttribute("question", qmap.get(key));
       // Process the body
       getJspBody().invoke(null);
     } catch (IOException e) {
       throw new JspException("Exception processing body");
     }
   }
  }
}