package com.apress.faq;

import java.util.*;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;

public class ListQuestions extends TagSupport {
  private String topic;
  /** Iterator over the question keys.
    * It is an instance variable because it is set in doStartTag()
    * and used in doAfterBody() */
  private Iterator qids;
  /** Map of questions keyed on question id.
    * It is an instance variable because it is set in doStartTag()
    * and used in doAfterBody() */
  private Map qmap;

  public void setTopic(String s) { topic = s; }

  public int doStartTag() throws JspException {
    Questions questions = new Questions();
    questions.setTopic(topic);

    qmap = questions.getQuestions();
    qids = qmap.keySet().iterator();
    try {
    // Write some preliminary data to the response
    pageContext.getOut().write("<h2>Questions for topic</h2>");
    pageContext.getOut().write("\nThe number of questions in topic " +
					  topic + " is " + qmap.size());
    } catch (IOException e) {
       throw new JspException("Error writing to out");
    }
    return EVAL_BODY_INCLUDE;
  }

  public int doAfterBody() throws JspException {
    // Create the link for a single question
    // Each time this  method is called by the page class,
    // the Iterator advancesto the next question
    if (qids.hasNext()) {
      String qid = (String) qids.next();
      String s = "<p>Question <a href=\"Questions.jsp?qid=" + qid +
                 "\">" + qid + "</a>: " +
                 qmap.get(qid) + "</p>";
      try {
        pageContext.getOut().write(s);
      } catch (IOException e) {
        throw new JspException("Error writing to out");
      }
      return EVAL_BODY_AGAIN;
    } else {
      // faqs.next() was false, so no more questions
      return SKIP_BODY;
    }
  }

  public int doEndTag() throws JspException {
    try {
      pageContext.getOut().write("<p>Click a link to see the answer</p>");
    } catch (IOException e) {
        throw new JspException("Error writing to out");
    }
    return EVAL_PAGE;
  }
}