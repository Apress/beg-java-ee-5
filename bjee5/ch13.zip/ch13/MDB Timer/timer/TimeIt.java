package timer;

import javax.ejb.Remote;

@Remote
public interface TimeIt {
  // The public business method on the timer bean
  public void startTimer();
}